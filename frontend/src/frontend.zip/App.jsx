import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from './components/Navbar';
import TaskFeed from './components/TaskFeed';
import PostTask from './components/PostTask';
import ProviderProfile from './components/ProviderProfile';
import SeekerProfile from './components/SeekerProfile'; // Import the new component
import Auth from './components/Auth';
import NearbyTasks from './pages/NearbyTasks';

axios.defaults.withCredentials = true;

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/auth/me');
        setUser(res.data.user);
      } catch (err) {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, []);

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:5000/api/auth/logout');
      setUser(null);
    } catch (err) {
      console.error("Logout failed", err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <Auth onLoginSuccess={(userData) => setUser(userData)} />
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-slate-50">
        <Navbar user={user} onLogout={handleLogout} />
        
        <main className="pb-20">
          <Routes>
            <Route path="/nearby-tasks" element={<NearbyTasks />} />
            {/* Home: Providers see the Feed, Seekers see their Profile */}
            <Route 
              path="/" 
              element={user.role === 'provider' ? <TaskFeed currentUser={user} /> : <SeekerProfile user={user} />} 
            />
            
            {/* Seeker Routes */}
            <Route 
              path="/post" 
              element={user.role === 'seeker' ? <PostTask currentUser={user} /> : <Navigate to="/" />} 
            />
            <Route 
              path="/seeker-profile" 
              element={user.role === 'seeker' ? <SeekerProfile user={user} /> : <Navigate to="/" />} 
            />

            {/* Provider Routes */}
            <Route 
              path="/provider-profile" 
              element={user.role === 'provider' ? <ProviderProfile user={user} /> : <Navigate to="/" />} 
            />

            {/* Catch-all redirect */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;