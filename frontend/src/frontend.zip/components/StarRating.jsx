// frontend/src/components/StarRating.jsx
import React, { useState } from 'react';

const StarRating = ({ onRate }) => {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);

  return (
    <div className="flex flex-col items-center p-4 bg-slate-50 rounded-xl border border-slate-200">
      <p className="text-sm font-semibold text-slate-600 mb-2">Rate the help received:</p>
      <div className="flex space-x-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            className={`text-3xl transition-colors ${
              (hover || rating) >= star ? 'text-amber-400' : 'text-slate-300'
            }`}
            onClick={() => {
              setRating(star);
              onRate(star);
            }}
            onMouseEnter={() => setHover(star)}
            onMouseLeave={() => setHover(0)}
          >
            ★
          </button>
        ))}
      </div>
    </div>
  );
};

export default StarRating;