import React, { useState, useEffect } from 'react';
import axios from 'axios';

// Sub-component for displaying the star rating visually
const RatingDisplay = ({ rating, totalReviews }) => {
  const formattedRating = Number(rating || 0).toFixed(1);
  return (
    <div className="flex items-center gap-3 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
      <div className="flex text-yellow-400 text-xl">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star}>{rating >= star ? '★' : '☆'}</span>
        ))}
      </div>
      <div>
        <span className="font-bold text-slate-900">{formattedRating}</span>
        <span className="text-slate-400 text-xs ml-1">({totalReviews || 0} reviews)</span>
      </div>
    </div>
  );
};

const ProviderProfile = ({ user }) => {
  const [myTasks, setMyTasks] = useState([]);
  const [stats, setStats] = useState({ averageRating: 0, totalReviews: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user?._id) return;
      
      try {
        // Fetch tasks and provider stats in parallel
        const [tasksRes, statsRes] = await Promise.all([
          axios.get('http://localhost:5000/api/tasks/my-tasks', { withCredentials: true }),
          axios.get(`http://localhost:5000/api/users/${user._id}/stats`)
        ]);
        
        setMyTasks(tasksRes.data);
        setStats(statsRes.data);
      } catch (err) {
        console.error("Error fetching provider data:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user?._id]);

  const handleComplete = async (taskId) => {
    try {
      await axios.patch(`http://localhost:5000/api/tasks/${taskId}/complete`, {}, { 
        withCredentials: true 
      });
      setMyTasks(prev => prev.map(t => t._id === taskId ? { ...t, status: 'completed' } : t));
    } catch (err) {
      alert("Error completing task");
    }
  };

  const accepted = myTasks.filter(t => t.status === 'accepted');
  const completed = myTasks.filter(t => t.status === 'completed');

  if (loading) return <div className="p-8 text-center text-slate-500 font-medium">Loading your dashboard...</div>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900">Welcome back, {user?.name}! 👋</h2>
          <p className="text-slate-500 mt-1">You're making a difference in the community.</p>
        </div>
        
        {/* Rating Display Integrated Here */}
        <RatingDisplay rating={stats.averageRating} totalReviews={stats.totalReviews} />
      </div>
      
      <div className="grid lg:grid-cols-3 gap-10">
        {/* Left Column: Tasks in Progress */}
        <section className="lg:col-span-2">
          <h3 className="text-xl font-bold mb-6 text-indigo-600 flex items-center gap-2">
            Tasks in Progress
            <span className="bg-indigo-100 text-indigo-600 px-3 py-0.5 rounded-full text-sm">
              {accepted.length}
            </span>
          </h3>
          
          {accepted.length === 0 ? (
            <div className="bg-white border-2 border-dashed border-slate-200 p-12 rounded-3xl text-center">
              <div className="text-4xl mb-4">🏠</div>
              <p className="text-slate-500 font-medium">No active tasks right now.</p>
              <p className="text-slate-400 text-sm mt-1">Head back to the feed to help someone today.</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-1 gap-6">
              {accepted.map(task => (
                <div key={task._id} className="bg-white border border-slate-200 p-6 rounded-3xl shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-bold text-slate-900 text-xl mb-1">{task.title}</h4>
                      <p className="text-slate-600 leading-relaxed">{task.description}</p>
                    </div>
                  </div>
                  
                  <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-5 mb-6">
                    <h5 className="text-xs font-black uppercase tracking-widest text-indigo-400 mb-3">Seeker Details</h5>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-xs font-bold">
                          {task.postedBy?.name?.charAt(0) || 'U'}
                        </div>
                        <p className="text-slate-700 font-semibold">{task.postedBy?.name || "Unknown User"}</p>
                      </div>
                      
                      <div className="flex items-start gap-3 text-sm">
                        <span className="text-slate-400 mt-0.5">📍</span>
                        <p className="text-slate-600">
                          <span className="font-bold block text-slate-800">Address:</span>
                          {task.postedBy?.address || task.address || "Contact seeker for location"}
                        </p>
                      </div>

                      <div className="flex items-center gap-3 text-sm">
                        <span className="text-slate-400">📞</span>
                        <p className="text-slate-600">
                          <span className="font-bold text-slate-800">Phone: </span>
                          {task.postedBy?.phone || "N/A"}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <a 
                      href={`tel:${task.postedBy?.phone}`}
                      className="flex-1 bg-white border border-slate-200 text-slate-700 py-3 rounded-2xl font-bold hover:bg-slate-50 transition-all text-center flex items-center justify-center gap-2"
                    >
                      Call Seeker
                    </a>
                    <button 
                      onClick={() => handleComplete(task._id)}
                      className="flex-[2] bg-indigo-600 text-white py-3 rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 active:scale-95"
                    >
                      Mark Finished
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Right Column: History */}
        <section>
          <h3 className="text-xl font-bold mb-6 text-slate-800">History</h3>
          <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100">
            {completed.length === 0 ? (
              <p className="text-sm text-slate-400 italic text-center py-4">No completed tasks yet.</p>
            ) : (
              <div className="space-y-4">
                {completed.map(task => (
                  <div key={task._id} className="bg-white p-4 rounded-2xl border border-slate-100 flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-bold text-slate-800">{task.title}</p>
                        <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest mt-1">
                          {new Date(task.updatedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="bg-emerald-100 text-emerald-600 p-2 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                    {/* Visual indicator of the rating received for this specific task */}
                    {task.rating && (
                      <div className="text-xs font-bold text-yellow-500 mt-1">
                        Rating: {'★'.repeat(task.rating)}{'☆'.repeat(5 - task.rating)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ProviderProfile;