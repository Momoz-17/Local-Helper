import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const PostTask = () => {
  const [formData, setFormData] = useState({ 
    title: '', 
    description: '',
    address: '' // Added address state to match backend destructuring
  });
  const [coords, setCoords] = useState({ lat: null, lng: null });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (pos) => setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => console.error("Location error:", err),
      { enableHighAccuracy: true } // Better precision for maps
    );
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!coords.lat || !coords.lng) {
      alert("Please wait for location to be captured.");
      return;
    }

    setLoading(true);
    try {
      const payload = {
        title: formData.title,
        description: formData.description,
        address: formData.address || "Current Location", // Fallback if empty
        longitude: coords.lng,
        latitude: coords.lat
        // REMOVED: postedBy: "Mohit" -> The backend gets this from your JWT token
      };
      
      // IMPORTANT: withCredentials: true ensures your login cookie/token is sent
      await axios.post('http://localhost:5000/api/tasks', payload, {
        withCredentials: true 
      });
      
      navigate('/'); 
    } catch (err) {
      console.error("Post failed:", err);
      // Backend returns { message: "...", error: "..." }. This displays the real reason:
      const errMsg = err.response?.data?.error || "Check if backend is running!";
      alert(`Failed to post task: ${errMsg}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto mt-10 p-8 bg-white rounded-2xl shadow-xl border border-slate-100">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">Request Local Help</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Task Title</label>
          <input 
            className="w-full p-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            placeholder="e.g. Fix ceiling fan"
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Nearby Landmark / Address</label>
          <input 
            className="w-full p-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            placeholder="e.g. Near City Mall, Sector 4"
            value={formData.address}
            onChange={(e) => setFormData({...formData, address: e.target.value})}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Details</label>
          <textarea 
            className="w-full p-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none h-32"
            placeholder="Describe what needs to be done..."
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            required
          />
        </div>

        <div className="text-xs text-slate-500 bg-slate-50 p-2 rounded-md italic">
          {coords.lat ? `📍 Coordinates: ${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}` : "⌛ Detecting location..."}
        </div>

        <button 
          type="submit" 
          disabled={loading}
          className={`w-full py-3 rounded-xl font-bold text-white transition-all ${loading ? 'bg-slate-400' : 'bg-indigo-600 hover:bg-indigo-700'}`}
        >
          {loading ? "Posting..." : "Post Request"}
        </button>
      </form>
    </div>
  );
};

export default PostTask;