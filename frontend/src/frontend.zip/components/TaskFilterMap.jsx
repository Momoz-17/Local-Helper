import React, { useState, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker } from '@react-google-maps/api';

const TaskFilterMap = ({ center, onLocationSelect }) => {
  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "YOUR_KEY"
  });

  // 1. Initialize state directly from props. 
  // This avoids the need for a useEffect on the first mount.
  const [markerPos, setMarkerPos] = useState(center);

  // 2. Memoized handler to fix the 'latLng' naming typo and prevent re-renders.
  const handleMapClick = useCallback((e) => {
    if (e.latLng) {
      const newCoords = { 
        lat: e.latLng.lat(), 
        lng: e.latLng.lng() 
      };
      setMarkerPos(newCoords);
      onLocationSelect(newCoords);
    }
  }, [onLocationSelect]);

  if (!isLoaded) return <div className="h-[300px] animate-pulse bg-slate-100 rounded-xl" />;

  return (
    <div className="rounded-2xl overflow-hidden border border-slate-200">
      <GoogleMap
        mapContainerStyle={{ width: '100%', height: '300px' }}
        center={center} 
        zoom={14}
        onClick={handleMapClick}
        options={{
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: false
        }}
      >
        {markerPos && <Marker position={markerPos} />}
      </GoogleMap>
    </div>
  );
};

export default TaskFilterMap;