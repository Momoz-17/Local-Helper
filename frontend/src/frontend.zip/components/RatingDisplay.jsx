import React from 'react';

const RatingDisplay = ({ rating, totalReviews }) => {
  // Round to 1 decimal place (e.g., 4.5)
  const formattedRating = Number(rating).toFixed(1);
  
  return (
    <div className="flex items-center gap-2">
      <div className="flex text-yellow-400">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star} className="text-lg">
            {rating >= star ? '★' : '☆'}
          </span>
        ))}
      </div>
      <span className="font-bold text-slate-700">{formattedRating}</span>
      <span className="text-slate-400 text-sm">({totalReviews} reviews)</span>
    </div>
  );
};

export default RatingDisplay;