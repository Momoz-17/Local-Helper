import React, { useState } from 'react';
import axios from 'axios';

const TaskCard = ({ task, currentUser, onAccept, onEdit, onDelete }) => {
  const [isUpdating, setIsUpdating] = useState(false);
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isRated, setIsRated] = useState(!!task.rating || task.status === 'completed');

  // Check if the logged-in user is the one who posted this task
  const isOwner = currentUser?.name === task.postedBy;

  const handleAcceptClick = async () => {
    setIsUpdating(true);
    await onAccept(task._id);
    setIsUpdating(false);
  };

  const handleRatingSubmit = async () => {
    if (rating === 0) return alert("Please select a star rating first.");
    setIsUpdating(true);
    try {
      await axios.post(`http://localhost:5000/api/tasks/${task._id}/rate`, {
        rating,
        feedback
      }, { withCredentials: true }); // Ensure cookies are sent
      
      setIsRated(true);
      alert("Task marked as completed and rated!");
    } catch (err) {
      const msg = err.response?.data?.message || "Could not submit rating.";
      alert(msg);
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow relative">
      <div className="flex justify-between items-start mb-4">
        <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase ${
          isRated ? 'bg-blue-100 text-blue-700' :
          task.status === 'open' ? 'bg-green-100 text-green-700' : 
          'bg-amber-100 text-amber-700'
        }`}>
          {isRated ? 'Completed' : task.status}
        </span>
        <p className="text-slate-400 text-xs italic text-right font-medium">
          Posted by {task.postedBy}
        </p>
      </div>
      
      <h3 className="text-lg font-bold text-slate-800 mb-2">{task.title}</h3>
      <p className="text-slate-600 text-sm mb-6 line-clamp-3">{task.description}</p>
      
      {/* 1. OWNER ACTIONS: Edit and Delete (Only visible to the creator) */}
      {isOwner && task.status === 'open' && (
        <div className="flex gap-4 mb-4 pb-4 border-b border-slate-50">
          <button 
            onClick={() => onEdit(task)} 
            className="text-indigo-600 text-xs font-bold uppercase hover:text-indigo-800 transition-colors"
          >
            Edit Post
          </button>
          <button 
            onClick={() => onDelete(task._id)} 
            className="text-red-500 text-xs font-bold uppercase hover:text-red-700 transition-colors"
          >
            Delete Post
          </button>
        </div>
      )}

      {/* 2. PROVIDER ACTION: Accept the task */}
      {task.status === 'open' && currentUser?.role === 'provider' && !isOwner && (
        <button 
          onClick={handleAcceptClick}
          disabled={isUpdating}
          className="w-full py-3 rounded-xl font-bold bg-slate-900 text-white hover:bg-slate-800 transition-all disabled:bg-slate-300 shadow-lg shadow-slate-200"
        >
          {isUpdating ? 'Processing...' : 'Accept Task'}
        </button>
      )}

      {/* 3. SEEKER ACTION: Rate and Complete */}
      {task.status === 'accepted' && !isRated && currentUser?.role === 'seeker' && isOwner && (
        <div className="mt-4 pt-4 border-t border-slate-100 space-y-4">
          <p className="text-xs font-bold text-center text-slate-500 uppercase tracking-wider">
            Help Received? Rate the Provider
          </p>
          <div className="flex justify-center space-x-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                className={`text-2xl transition-colors ${
                  (hover || rating) >= star ? 'text-amber-400' : 'text-slate-200'
                }`}
                onClick={() => setRating(star)}
                onMouseEnter={() => setHover(star)}
                onMouseLeave={() => setHover(0)}
              >
                ★
              </button>
            ))}
          </div>
          <textarea
            className="w-full p-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
            rows="2"
            placeholder="Any feedback for the volunteer?"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />
          <button 
            onClick={handleRatingSubmit}
            disabled={isUpdating}
            className="w-full py-2 rounded-lg font-bold bg-indigo-600 text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
          >
            {isUpdating ? 'Saving...' : 'Mark as Completed'}
          </button>
        </div>
      )}

      {/* 4. PROVIDER WAITING STATE */}
      {task.status === 'accepted' && !isRated && currentUser?.role === 'provider' && (
        <div className="text-center p-3 bg-amber-50 rounded-xl border border-amber-100">
          <p className="text-sm font-medium text-amber-700 italic">
            You've accepted this. Waiting for {task.postedBy} to complete.
          </p>
        </div>
      )}

      {/* 5. FINAL STATE: Show rating result */}
      {isRated && (
        <div className="mt-4 pt-4 border-t border-slate-100 text-center">
          <div className="text-amber-400 text-xl mb-1">
            {"★".repeat(task.rating || rating)}{"☆".repeat(5 - (task.rating || rating))}
          </div>
          <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Archived</p>
        </div>
      )}
    </div>
  );
};

export default TaskCard;