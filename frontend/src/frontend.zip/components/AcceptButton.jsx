import React, { useState } from 'react';
import axios from 'axios';

const AcceptTaskButton = ({ taskId, currentUser, onTaskAccepted }) => {
  const [loading, setLoading] = useState(false);

  // 1. Role-Based UI Guard: Only show if the user is a 'provider'
  if (currentUser?.role !== 'provider') {
    return null; 
  }

  const handleAccept = async () => {
    setLoading(true);
    try {
      // 2. The secure call: No need to pass headers! 
      // The cookie is sent automatically because of withCredentials: true
      const response = await axios.patch(`http://localhost:5000/api/tasks/${taskId}/accept`);
      
      // 3. Update the UI (e.g., remove from feed or change status)
      if (onTaskAccepted) {
        onTaskAccepted(response.data);
      }
      alert("Task successfully accepted!");
    } catch (err) {
      const errorMsg = err.response?.data?.message || "Could not accept task.";
      alert(`Error: ${errorMsg}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleAccept}
      disabled={loading}
      className={`px-6 py-2 rounded-xl font-bold transition-all shadow-md 
        ${loading 
          ? 'bg-slate-300 cursor-not-allowed' 
          : 'bg-green-600 text-white hover:bg-green-700 active:scale-95'
        }`}
    >
      {loading ? 'Processing...' : 'Accept Task'}
    </button>
  );
};

export default AcceptTaskButton;