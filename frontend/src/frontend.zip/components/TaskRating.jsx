import React, { useState } from 'react';
import axios from 'axios';

const TaskRating = ({ taskId, onComplete }) => {
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (rating === 0) return alert("Please select a star rating");
    
    setSubmitting(true);
    try {
      await axios.put(`http://localhost:5000/api/tasks/rate/${taskId}`, { 
        rating, 
        feedback 
      });
      onComplete(); // Refresh the list or close modal
    } catch (err) {
      alert(err.response?.data?.message || "Failed to submit review");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-50 p-6 rounded-2xl border border-slate-200 mt-4">
      <h4 className="font-bold text-slate-800 mb-4">Rate the Provider's Work</h4>
      
      {/* Star Selector */}
      <div className="flex gap-2 mb-4">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            className={`text-2xl ${rating >= star ? 'text-yellow-400' : 'text-slate-300'}`}
          >
            ★
          </button>
        ))}
      </div>

      <textarea
        className="w-full p-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        placeholder="Share your experience (optional)..."
        rows="3"
        value={feedback}
        onChange={(e) => setFeedback(e.target.value)}
      />

      <button
        disabled={submitting}
        className="mt-4 w-full bg-indigo-600 text-white py-2 rounded-xl font-bold hover:bg-indigo-700 disabled:bg-slate-400 transition-colors"
      >
        {submitting ? "Submitting..." : "Submit Review"}
      </button>
    </form>
  );
};

export default TaskRating;