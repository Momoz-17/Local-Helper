import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TaskRating from '../components/TaskRating'; // Ensure this path matches your folder structure

const SeekerProfile = ({ user }) => {
  const [myRequests, setMyRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // Define fetch logic outside useEffect so it can be reused after rating
  const fetchMyRequests = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/tasks/my-requests', { 
        withCredentials: true 
      });
      setMyRequests(res.data);
    } catch (err) {
      console.error("Error fetching requests:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyRequests();
  }, []);

  const handleConfirmCompletion = async (taskId) => {
    try {
      await axios.patch(`http://localhost:5000/api/tasks/${taskId}/complete`, {}, { 
        withCredentials: true 
      });
      
      // Refresh list to trigger the "Completed" state and show Rating component
      fetchMyRequests();
      alert("Task marked as completed! You can now leave a review for your provider.");
    } catch (err) {
      alert("Error confirming completion");
    }
  };

  if (loading) return <div className="p-8 text-center text-slate-500 font-medium">Loading your requests...</div>;

  const inProgress = myRequests.filter(t => t.status === 'accepted');
  const pending = myRequests.filter(t => t.status === 'open');
  const history = myRequests.filter(t => t.status === 'completed');

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-10">
        <h2 className="text-3xl font-extrabold text-slate-900">
          Welcome back, {user?.name || 'Seeker'}
        </h2>
        <p className="text-slate-500 mt-1">Track your active requests and connect with providers.</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-10">
          
          {/* 1. IN PROGRESS SECTION */}
          <section>
            <h3 className="text-xl font-bold mb-6 text-emerald-600 flex items-center gap-2">
              Someone is Helping! 
              <span className="bg-emerald-100 text-emerald-600 px-3 py-0.5 rounded-full text-sm">{inProgress.length}</span>
            </h3>
            {inProgress.length === 0 ? (
              <p className="text-slate-400 italic bg-slate-50 p-6 rounded-2xl border border-dashed">No active helpers currently. Hang tight!</p>
            ) : (
              inProgress.map(task => (
                <div key={task._id} className="bg-white border-2 border-emerald-100 p-6 rounded-3xl shadow-sm mb-6">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="font-bold text-slate-900 text-xl">{task.title}</h4>
                    <span className="bg-emerald-50 text-emerald-700 text-xs font-black uppercase px-3 py-1 rounded-full">Accepted</span>
                  </div>
                  
                  {/* Provider Contact Card */}
                  <div className="bg-slate-50 rounded-2xl p-5 mb-6 border border-slate-100">
                    <h5 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-3">Your Helper's Info</h5>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-12 h-12 rounded-full bg-emerald-600 flex items-center justify-center text-white text-lg font-bold">
                        {task.acceptedBy?.name?.charAt(0) || 'P'}
                      </div>
                      <div>
                        <p className="text-slate-900 font-bold text-lg">{task.acceptedBy?.name || "Volunteer"}</p>
                        <p className="text-slate-500 text-sm">Community Provider</p>
                      </div>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <a href={`tel:${task.acceptedBy?.phone}`} className="flex-1 bg-white border border-slate-200 text-slate-700 py-2.5 rounded-xl font-bold text-center hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
                        📞 Call {task.acceptedBy?.phone}
                      </a>
                      <button 
                        onClick={() => handleConfirmCompletion(task._id)}
                        className="flex-1 bg-emerald-600 text-white py-2.5 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                      >
                        Confirm Help Received
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </section>

          {/* 2. PENDING SECTION */}
          <section>
            <h3 className="text-xl font-bold mb-6 text-slate-800 flex items-center gap-2">
              Waiting for Providers
              <span className="bg-slate-100 text-slate-500 px-3 py-0.5 rounded-full text-sm">{pending.length}</span>
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {pending.map(task => (
                <div key={task._id} className="bg-white border border-slate-200 p-5 rounded-2xl opacity-75">
                  <h4 className="font-bold text-slate-800">{task.title}</h4>
                  <p className="text-sm text-slate-500 mt-1 line-clamp-2">{task.description}</p>
                  <div className="mt-4 flex items-center text-xs text-slate-400 font-medium italic">
                    📍 {task.address || "Local Area"}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* 3. HISTORY SIDEBAR & RATING */}
        <aside>
          <h3 className="text-xl font-bold mb-6 text-slate-800">Past Requests</h3>
          <div className="space-y-6">
            {history.length === 0 && <p className="text-sm text-slate-400 italic">No history yet.</p>}
            {history.map(task => (
              <div key={task._id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <p className="font-bold text-slate-800">{task.title}</p>
                  <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded text-slate-500 font-bold uppercase">Done</span>
                </div>
                
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">
                  Completed {new Date(task.updatedAt).toLocaleDateString()}
                </p>

                {/* Rating & Review Logic */}
                <div className="mt-4 pt-4 border-t border-slate-100">
                  {task.status === 'completed' && !task.rating && (
                    <TaskRating taskId={task._id} onComplete={fetchMyRequests} />
                  )}

                  {task.rating && (
                    <div className="p-3 bg-indigo-50 rounded-xl">
                      <p className="text-xs font-bold text-indigo-700 flex items-center gap-1">
                        ⭐ {task.rating}/5 Rating Given
                      </p>
                      {task.feedback && (
                        <p className="text-xs text-slate-600 italic mt-1 leading-relaxed">
                          "{task.feedback}"
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};

export default SeekerProfile;