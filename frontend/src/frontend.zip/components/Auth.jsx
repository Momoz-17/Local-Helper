import React, { useState } from 'react';
import axios from 'axios';

const Auth = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState('seeker'); 
  const [step, setStep] = useState('form'); 
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',    // Added for contact
    address: '',  // Added for location
    otp: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      // Step 1: Send registration data including phone and address
      await axios.post('http://localhost:5000/api/auth/register', { 
        name: formData.name,
        email: formData.email,
        password: formData.password,
        phone: formData.phone,
        address: formData.address,
        role: role 
      });
      
      setStep('otp');
      alert("OTP sent to your email!");
    } catch (err) {
      const errorMsg = err.response?.data?.message || "Registration failed";
      alert(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/api/auth/verify-otp', {
        email: formData.email,
        otp: formData.otp
      });
      onLoginSuccess(res.data.user); 
    } catch (err) {
      alert(err.response?.data?.message || "Invalid OTP");
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', {
        email: formData.email,
        password: formData.password
      });
      onLoginSuccess(res.data.user);
    } catch (err) {
      alert(err.response?.data?.message || "Login failed. Check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-2xl border border-slate-100">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-2">
          {step === 'otp' ? 'Verify Email' : isLogin ? 'Welcome Back' : 'Create Account'}
        </h2>
        <p className="text-slate-500 text-sm">
          {step === 'otp' ? `Enter the code sent to ${formData.email}` : 'Join the help seeker/provider platform'}
        </p>
      </div>

      {step === 'form' ? (
        <form onSubmit={isLogin ? handleLogin : handleRegister} className="space-y-4">
          {!isLogin && (
            <>
              <input 
                name="name" 
                placeholder="Full Name" 
                value={formData.name}
                onChange={handleChange} 
                required 
                className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" 
              />
              
              <div className="flex gap-2 p-1 bg-slate-100 rounded-xl">
                <button 
                  type="button" 
                  onClick={() => setRole('seeker')} 
                  className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${role === 'seeker' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                >
                  Need Help
                </button>
                <button 
                  type="button" 
                  onClick={() => setRole('provider')} 
                  className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${role === 'provider' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
                >
                  Provider
                </button>
              </div>

              {/* NEW: Phone Input */}
              <input 
                name="phone" 
                type="tel"
                placeholder="Phone Number (e.g. +91...)" 
                value={formData.phone}
                onChange={handleChange} 
                required 
                className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" 
              />

              {/* NEW: Address Input */}
              <textarea 
                name="address" 
                placeholder="Full Address / Area" 
                value={formData.address}
                onChange={handleChange} 
                required 
                className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 h-20 resize-none" 
              />
            </>
          )}
          
          <input 
            name="email" 
            type="email" 
            placeholder="Email Address" 
            value={formData.email}
            onChange={handleChange} 
            required 
            className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" 
          />
          
          <input 
            name="password" 
            type="password" 
            placeholder="Password" 
            value={formData.password}
            onChange={handleChange} 
            required 
            className="w-full p-3 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" 
          />
          
          <button 
            type="submit" 
            disabled={loading}
            className={`w-full text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-indigo-100 ${loading ? 'bg-slate-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'}`}
          >
            {loading ? 'Processing...' : (isLogin ? 'Login' : 'Register & Send OTP')}
          </button>
          
          <button 
            type="button" 
            onClick={() => {
              setIsLogin(!isLogin);
              setStep('form'); 
            }} 
            className="w-full text-sm text-indigo-600 font-medium hover:underline"
          >
            {isLogin ? "Don't have an account? Register" : "Already have an account? Login"}
          </button>
        </form>
      ) : (
        <form onSubmit={handleVerifyOTP} className="space-y-4">
          <input 
            name="otp" 
            placeholder="6-digit OTP" 
            value={formData.otp}
            onChange={handleChange} 
            required 
            className="w-full p-4 text-center text-2xl font-mono tracking-widest rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500" 
            maxLength="6" 
          />
          <button 
            type="submit" 
            disabled={loading}
            className={`w-full text-white py-3 rounded-xl font-bold transition-all ${loading ? 'bg-slate-400' : 'bg-green-600 hover:bg-green-700'}`}
          >
            {loading ? 'Verifying...' : 'Verify & Start'}
          </button>
          <button 
            type="button" 
            onClick={() => setStep('form')} 
            className="w-full text-sm text-slate-500 hover:underline"
          >
            Go Back
          </button>
        </form>
      )}
    </div>
  );
};

export default Auth;