import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TaskFilterMap from '../components/TaskFilterMap';

const NearbyTasks = () => {
  const [tasks, setTasks] = useState([]);
  const [coords, setCoords] = useState({ lat: 19.0760, lng: 72.8777 }); // Default: Mumbai
  const [loading, setLoading] = useState(true);
  const [isSearching, setIsSearching] = useState(false);

  // Fetch tasks based on specific coordinates
  const fetchTasks = async (searchCoords) => {
    setIsSearching(true);
    try {
      // Note: distance is optional, defaults to 10km in our backend controller
      const res = await axios.get('http://localhost:5000/api/tasks/nearby', {
        params: { 
          lat: searchCoords.lat, 
          lng: searchCoords.lng,
          distance: 10000 
        }
      });
      setTasks(res.data);
    } catch (err) {
      console.error("Error fetching nearby tasks:", err);
    } finally {
      setIsSearching(false);
    }
  };

  // Initial GPS lock on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const newCoords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setCoords(newCoords);
          fetchTasks(newCoords);
          setLoading(false);
        },
        (error) => {
          console.warn("Location blocked or unavailable, using default.", error);
          fetchTasks(coords); 
          setLoading(false);
        }
      );
    } else {
      fetchTasks(coords);
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600 mb-4"></div>
        <p className="text-slate-500 font-medium">Locating nearby help requests...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <header className="mb-8">
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Nearby Help Requests</h1>
        <p className="text-slate-500 mt-2">
          Showing tasks within 10km of your selected location.
        </p>
      </header>

      {/* Map Filter Section */}
      <section className="relative">
        <TaskFilterMap 
          center={coords} 
          onLocationSelect={(newCoords) => {
            setCoords(newCoords);
            fetchTasks(newCoords);
          }} 
        />
        {isSearching && (
          <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full shadow-sm border border-slate-200 text-xs font-bold text-indigo-600 animate-pulse">
            Updating Feed...
          </div>
        )}
      </section>

      {/* Results Section */}
      <div className="mt-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-800">Available Tasks</h2>
          <span className="text-sm text-slate-400 font-medium">{tasks.length} found</span>
        </div>

        <div className="grid gap-4">
          {tasks.length > 0 ? (
            tasks.map(task => (
              <div 
                key={task._id} 
                className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-100 transition-all cursor-pointer group"
              >
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-xl text-slate-800 group-hover:text-indigo-600 transition-colors">
                    {task.title}
                  </h3>
                  <span className="px-3 py-1 bg-green-50 text-green-600 text-xs font-bold rounded-full uppercase tracking-wider">
                    {task.status}
                  </span>
                </div>
                <p className="text-slate-600 mt-2 line-clamp-2">{task.description}</p>
                <div className="mt-4 flex items-center text-slate-400 text-xs font-medium">
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  {task.address}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
              <p className="text-slate-400 italic">No open tasks found in this area.</p>
              <p className="text-slate-400 text-sm">Try dragging the map to a different location.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NearbyTasks;